# Work-Experience Brief  
### *Frontend Development — “Mini Events Listing” Component*

---

## Scenario  
Your agency is building a microsite for a local charity that runs community events. They need a small, 
reusable component that lists the next three events in a neat card layout and adapts gracefully from 
desktop to mobile.

---

## What to deliver

| Item | Description |
|------|-------------|
| **1&nbsp;· `events.html`** | Stand-alone HTML file containing the markup for the component. No external 
frameworks; plain HTML + CSS + vanilla JS. |
| **2&nbsp;· `events.css`** | Styles for the component in a separate file, written mobile-first |
| **3&nbsp;· `events.js`** | A tiny script that reads an array of event objects and injects the cards into the DOM. |

Make sure to comment your code explaining:
* How the JS works in plain English
* How you went about styling the component, including any design decisions you made
* How you would improve the component if you had more time.
* One thing you found tricky and how you solved it.

---

## Functional requirements

1. **Static data**  
   Place this array at the top of `events.js`:

   ```js
   const events = [
     { title: 'Youth Coding Club', date: '2025-05-07', time: '16:00', venue: 'The Hive' },
     { title: 'Community Hackathon', date: '2025-05-14', time: '10:00', venue: 'Town Hall' },
     { title: 'Accessibility Workshop', date: '2025-05-21', time: '13:30', venue: 'Library Hub' }
   ];
   ```
2. **Card layout**
   * Show title, date (DD Month YYYY), time, and venue on each card.  
   * On screens ≥ 768 px display the three cards in a row; on smaller screens stack them vertically.

3. **Visual polish**
   * Soft drop-shadow, 8 px border-radius.
   * Use a pleasant Google Font (e.g. Inter) via CDN.
   * Subtle hover state: card lifts 2 px with a smooth transition.

4. **Accessibility touches**
   * All text meets WCAG AA contrast.
   * Use role="list" and role="listitem" where appropriate.
   * No external libraries other than the Google Font link.

## Stretch goals (only if you finish early)
* Add a simple filter input that hides cards whose title does not match the typed text.
* Replace the static array with a fetch from events.json (you can mock it locally).